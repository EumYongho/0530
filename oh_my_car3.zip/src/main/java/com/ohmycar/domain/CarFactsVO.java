package com.ohmycar.domain;

import lombok.Data;

@Data
public class CarFactsVO {
    private int factId;
    private String factText;
}
